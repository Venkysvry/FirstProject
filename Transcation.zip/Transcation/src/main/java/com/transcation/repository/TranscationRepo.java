package com.transcation.repository;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

import com.transcation.Entity.Transcation;

public interface TranscationRepo extends JpaRepository<Transcation, String> {
	Page<Transcation> findByAccountIdOrderByCreatedAtDesc(String accountId, Pageable pageable);

	Page<Transcation> findByAccountIdAndStatusOrderByCreatedAtDesc(String accountId, String status, Pageable pageable);

	Page<Transcation> findByCorrelationId(String correlationId, Pageable pageable);
}
