package com.transcation.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.transcation.Entity.Transcation;
import com.transcation.service.TranscationService;

@RestController
@RequestMapping("/transcationApi")
public class TranscationController {
	@Autowired
	private TranscationService txnservice;

	@PostMapping("/createTranscation")
	public ResponseEntity<String> createTranscation(@Validated @RequestBody Transcation txn) {
		String response = txnservice.postTranscation(txn);
		return new ResponseEntity<>(response, HttpStatusCode.valueOf(201));
	}

	@GetMapping("/getTranscationbyaccountandcreatedBy/{accountId}")
	public ResponseEntity<Page<Transcation>> gettranscationByaccountId(@PathVariable String accountId, Pageable page) {
		System.out.println(this);
		Page<Transcation> list = txnservice.getTranscationByaccountId(accountId, page);
		return new ResponseEntity<>(list, HttpStatusCode.valueOf(200));
	}

	@GetMapping("/getTranscationbyaccountandcreatedBy/{accountId}/{status}")
	public ResponseEntity<Page<Transcation>> gettranscationByaccountIdAndStatus(@PathVariable String accountId,
			@PathVariable String status, Pageable page) {
		Page<Transcation> list = txnservice.getByAccountIdAndStatusOrderByCreatedAtDesc(accountId, status, page);
		return new ResponseEntity<>(list, HttpStatusCode.valueOf(200));
	}
}
