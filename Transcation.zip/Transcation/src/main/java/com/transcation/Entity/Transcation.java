package com.transcation.Entity;

import java.math.BigDecimal;
import java.time.Instant;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Index;
import jakarta.persistence.Table;

@Entity
@Table(name = "transcations", indexes = { @Index(name = "idx_tnx_id", columnList = "transcation_Id"),
		@Index(name = "idx_txn_account_created_at", columnList = "account_Id,created_At"),
		@Index(name = "idx_correlation_Id", columnList = "correlation_Id", unique = true),
		@Index(name = "idx_status", columnList = "status")

})

public class Transcation implements Comparable<Transcation> {
	@Id
	@Column(name = "transcation_Id")
	private String transcationId;
	@Column(name = "account_Id", nullable = false)
	private String accountId;
	private BigDecimal amount;
	private String currency;
	@Column(name = "status", nullable = false)
	private String status;
	@Column(name = "created_At", nullable = false)
	private Instant createdAt;
	private Instant updatedAt;
	@Column(name = "correlation_Id", nullable = false, unique = true)
	private String correlationId;

	public String getTranscationId() {
		return transcationId;
	}

	public void setTranscationId(String transcationId) {
		this.transcationId = transcationId;
	}

	public String getAccountId() {
		return accountId;
	}

	public void setAccountId(String accountId) {
		this.accountId = accountId;
	}

	public BigDecimal getAmount() {
		return amount;
	}

	public void setAmount(BigDecimal amount) {
		this.amount = amount;
	}

	public String getCurrency() {
		return currency;
	}

	public void setCurrency(String currency) {
		this.currency = currency;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Instant getCreatedAt() {
		return createdAt;
	}

	public void setCreatedAt(Instant createdAt) {
		this.createdAt = createdAt;
	}

	public Instant getUpdatedAt() {
		return updatedAt;
	}

	public void setUpdatedAt(Instant updatedAt) {
		this.updatedAt = updatedAt;
	}

	public String getCorrelationId() {
		return correlationId;
	}

	public void setCorrelationId(String correlationId) {
		this.correlationId = correlationId;
	}

	@Override
	public int compareTo(Transcation o) {

		return this.createdAt.compareTo(o.createdAt);
	}

}
