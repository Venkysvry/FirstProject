package com.transcation.service;

public interface Dummy1Interface {
	default String defaultmethod() {
		return "this is dummy method";

	}

}
