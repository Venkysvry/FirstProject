package com.transcation.service;

public interface DummyInterface {
	final int x = 10;

	String dummymethod();

	default String defaultmethod() {
		privatexmethod();
		System.out.println(x);
		staticmethod();
		return "this is dummy method";

	}

	public  static String staticmethod() {
		return null;

	}

	private String privatexmethod() {
		return null;

	}
}
