package com.transcation.service;

public class DummyImplementation implements DummyInterface, Dummy1Interface {

	@Override
	public String dummymethod() {
		//DummyInterface.super.x;
		return "dummy method";
	}

	@Override
	public String defaultmethod() {
		return DummyInterface.staticmethod();
	}

}
