package com.transcation.service;

public class ABCD extends Xyz {
	String x = "10";

	public ABCD(String accountNumber, String holderName) {
		super(accountNumber, holderName);

	}

	@Override
	public String getAccountNumber() {
		x = "11";
		return super.getAccountNumber();

	}

}
