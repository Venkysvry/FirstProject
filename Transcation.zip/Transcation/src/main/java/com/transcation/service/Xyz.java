package com.transcation.service;

public class Xyz {

	private final String accountNumber;
	private final String holderName;

	public Xyz(String accountNumber, String holderName) {
		this.accountNumber = accountNumber;
		this.holderName = holderName;
	}

	public String getAccountNumber() {
		return accountNumber;
	}

	public String getHolderName() {
		return holderName;

	}

}
