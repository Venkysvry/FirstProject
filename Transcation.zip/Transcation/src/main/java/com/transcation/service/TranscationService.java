package com.transcation.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.config.BeanPostProcessor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import com.transcation.Entity.Transcation;
import com.transcation.repository.TranscationRepo;

import jakarta.annotation.PostConstruct;
import jakarta.transaction.Transactional;

@Service
public class TranscationService {
	@Autowired
	private TranscationRepo txnrepo;

	@PostConstruct
	public void init() {
		System.out.println(BeanPostProcessor.class.getName());
		System.out.println("object is fully initialized");
	}

	@Transactional
	public String postTranscation(Transcation txn) {
		txnrepo.save(txn);
		return "transcation successfully";
	}

	public Page<Transcation> getTranscationByaccountId(String AccountId, Pageable page) {
		return txnrepo.findByAccountIdOrderByCreatedAtDesc(AccountId, page);

	}

	public Page<Transcation> getByAccountIdAndStatusOrderByCreatedAtDesc(String AccountId, String status,
			Pageable page) {

		return txnrepo.findByAccountIdAndStatusOrderByCreatedAtDesc(AccountId, status, page);

	}

}
