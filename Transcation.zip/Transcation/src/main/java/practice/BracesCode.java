package practice;

import java.util.ArrayList;
import java.util.List;

public class BracesCode {

	public static void main(String[] args) {

		List<Integer> output = new ArrayList<>();
		List<String> braceSet = List.of("(()))(");

		for (String s : braceSet) {
			int balance = 0;
			boolean valid = true;

			for (char c : s.toCharArray()) {
				if (c == '(')
					balance++;
				else if (c == ')')
					balance--;

				if (balance < 0) { // closing too early
					valid = false;
					break;
				}
			}

			if (balance != 0)
				valid = false;

			output.add(valid ? 1 : 0);
		}

		System.out.println(output);

	}

}






