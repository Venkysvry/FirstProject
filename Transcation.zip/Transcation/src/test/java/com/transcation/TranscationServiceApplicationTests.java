package com.transcation;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TranscationServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
